
import java.awt.image.BufferedImage;

/**
 *
 * @author EGYPT_LAPTOP
 */
public abstract class People implements ICrosser{
    private String label;
    private int eatingRank;
    @Override
    public boolean canSail() {
        return true;
    }

    @Override
   abstract public double getWeight();
       

    @Override
    public int getEatingRank() {
       return 10;
    }

    @Override
    abstract public BufferedImage[] getImages();
       

    @Override
    abstract public ICrosser makeCopy();
      

    @Override
    abstract public void setLabelToBeShown(String label);
   

    @Override
     public String getLabelToBeShown(){
         return label;
     }
         
    
    
}
