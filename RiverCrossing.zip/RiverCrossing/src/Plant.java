
import java.awt.image.BufferedImage;

/**
 *
 * @author EGYPT_LAPTOP
 */
public class Plant implements ICrosser{
    private int eatingRank=2;
    private double weight=0.5;

    @Override
    public boolean canSail() {
      return false;
    }

    @Override
    public double getWeight() {
       return weight;
    }

    @Override
    public int getEatingRank() {
    return eatingRank;
    }

    @Override
    public BufferedImage[] getImages() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public Plant() {
    }

    @Override
    public ICrosser makeCopy() {
     return new Plant();
    }

    @Override
    public void setLabelToBeShown(String label) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String getLabelToBeShown() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
}
