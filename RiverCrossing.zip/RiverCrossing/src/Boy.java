
import java.awt.image.BufferedImage;

/**
 *
 * @author EGYPT_LAPTOP
 */
public class Boy extends People{
    private double weight=60;

    public Boy() {
    }

    public String getLabel() {
        return label;
    }
    private String label="60";

    @Override
    public double getWeight() {
    return weight;
    }
    @Override
    public BufferedImage[] getImages() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ICrosser makeCopy() {
       return new Boy();
    }

    @Override
    public void setLabelToBeShown(String label) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
