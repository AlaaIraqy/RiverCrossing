
public class Rabbit extends Herbivorous{
    private String label="5";
    private double weight=5;

    Rabbit() {
    }

    public String getLabel() {
        return label;
    }

   
    public double getWeight() {
        return weight;
    }    

    @Override
    public ICrosser makeCopy() {
       return new Rabbit();
    }
}
