
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Heba Ahmed
 */
public class Carnivorous implements ICrosser {
    private String label;
    private double weight;
    BufferedImage images[]=new BufferedImage[2];
    carnivorousFactory animals=new carnivorousFactory();
    @Override
    public boolean canSail(){
        return false;
    }

    @Override
    public double getWeight(){
        weight=animals.getFactory().getWeight();
        setLabelToBeShown(Double.toString(weight));
        return weight;
    }
    @Override
    public int getEatingRank(){
        return 4;
    }
    
    @Override
    public BufferedImage[] getImages(){
        if(weight==150){
            try {
                images[0] = ImageIO.read(new File("FrontLion.png"));
                images[1] = ImageIO.read(new File("BackLion.png"));
            } catch (IOException ex) {
                Logger.getLogger(Carnivorous.class.getName()).log(Level.SEVERE, null, ex);
            }
                return images;
        }
        else if (weight==50){
            try {
                images[0] = ImageIO.read(new File("WolfFront.png"));
                 images[1] = ImageIO.read(new File("WolfBack.png"));
            } catch (IOException ex) {
                Logger.getLogger(Carnivorous.class.getName()).log(Level.SEVERE, null, ex);
            }
              return images;
        }
        
            
        return null;
    }

    /**
     *
     * @return
     */
    @Override
    public String getLabelToBeShown(){
        return label;
    }

    /**
     *
     * @return
     */
    @Override
    public ICrosser makeCopy(){
       return null;
    }

    @Override
    public void setLabelToBeShown(String label) {
        this.label=label;
    }
}