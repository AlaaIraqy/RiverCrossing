
import java.awt.image.BufferedImage;

/**
 *
 * @author EGYPT_LAPTOP
 */
public class Woman extends People{
    private String label="80";
    private double weight=80;

    @Override
    public double getWeight() {
       return weight;
    }

    @Override
    public BufferedImage[] getImages() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ICrosser makeCopy() {
        return new Woman();
    }

    public String getLabel() {
        return label;
    }

    public Woman() {
    }

    @Override
    public void setLabelToBeShown(String label) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
}
