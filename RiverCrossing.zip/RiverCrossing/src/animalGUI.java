import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
public class animalGUI {
    Image image;
    private double positionX;
    private double positionY;
    private double width;
    private double height;
    public animalGUI(Image image){
        this.image=image;
        this.positionX=0;
        this.positionY=0;
        width=image.getWidth();
        height=image.getHeight();
    }
    public Image getImage() {
        return image;
    }

    public void setImage(Image image) {
        this.image = image;
    }

    public double getPositionX() {
        return positionX;
    }

    public void setPositionX(double positionX) {
        this.positionX = positionX;
    }

    public double getPositionY() {
        return positionY;
    }

    public void setPositionY(double positionY) {
        this.positionY = positionY;
    }

    public double getWidth() {
        return width;
    }

    public void setWidth(double width) {
        this.width = width;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    void render(GraphicsContext gc) {
        gc.drawImage(image, positionX, positionY);
    }
    
}
