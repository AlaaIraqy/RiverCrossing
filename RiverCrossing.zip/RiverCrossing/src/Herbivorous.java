import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
public class Herbivorous implements ICrosser{
    private String label;
    private double weight;  
    BufferedImage images[]=new BufferedImage[2];
    HerbivorousFactory factory = new HerbivorousFactory();

    @Override
    public boolean canSail() {
       return false;
    }

    @Override
   public double getWeight(){
       weight=factory.getAnimal().getWeight();
        setLabelToBeShown(Double.toString(weight));
        return weight;
   }

    @Override
    public int getEatingRank() {
      return 3;
    }

    @Override
    public BufferedImage[] getImages() {
      if(weight==20){
            try {
                images[0] = ImageIO.read(new File("ShaunFront.png"));
                images[1] = ImageIO.read(new File("ShaunBack.png"));
            } catch (IOException ex) {
                Logger.getLogger(Carnivorous.class.getName()).log(Level.SEVERE, null, ex);
            }
                return images;
        }
        else if (weight==5){
            try {
                images[0] = ImageIO.read(new File("FrontRabbit.png"));
                 images[1] = ImageIO.read(new File("BackRabbit.png"));
            } catch (IOException ex) {
                Logger.getLogger(Carnivorous.class.getName()).log(Level.SEVERE, null, ex);
            }
              return images;
        }
        
            
        return null;
    }

    @Override
    public ICrosser makeCopy(){
        return null;
    }

    @Override
    public void setLabelToBeShown(String label) {
      this.label=label;
    }

    @Override
    public String getLabelToBeShown() {
        return label;
    }
   
    
}
