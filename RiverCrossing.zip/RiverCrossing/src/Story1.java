
import java.util.List;
import java.util.ArrayList;

public class Story1 implements ICrossingStrategy {

    public boolean isValid(List<ICrosser> rightBankCrossers, List<ICrosser> leftBankCrossers, List<ICrosser> boatRiders) {
        boolean valid = false;
        for (int i = 0; i < boatRiders.size(); i++) {
            ICrosser x = boatRiders.get(i);
            if (x.canSail()) {
                valid = true;
                break;
            }
        }
        if (valid == false) {
            return false;
        }
        if (leftBankCrossers.size() == 3) {
            return false;
        } else if (leftBankCrossers.size() == 2) {
            int diff=leftBankCrossers.get(0).getEatingRank()-leftBankCrossers.get(1).getEatingRank();
        if(diff==1 ||diff==-1)
            return false;
        }
        return true;
    }

    public List<ICrosser> getInitialCrossers() {
         List<ICrosser> c = new ArrayList<>();
        HerbivorousFactory f = new HerbivorousFactory();
        c.add(new Man());
        c.add(new Plant());
        c.add(f.getAnimal());
        c.add(f.getAnimal());
        return c;
    }

    @Override
    public String[] getInstructions() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

   
    
}
