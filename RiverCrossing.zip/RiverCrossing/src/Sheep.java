
public class Sheep extends Herbivorous {
    private String label="20";
    private double weight=20;

    Sheep() {
    }

    public double getWeight() {
        return weight;
    }

    public String getLabel() {
        return label;
    }

    @Override
    public ICrosser makeCopy() {
      return new Sheep();
    }
    
    
    
}
