
import java.util.Random;
/**
 *
 * @author EGYPT_LAPTOP
 */
public class HerbivorousFactory {
   
    public Herbivorous getAnimal()
    {
         int i;
        Random rand = new Random();
        i=rand.nextInt(2);
        if (i==0)
            return new Sheep();
        else if (i==1)
            return new Rabbit();
        return null;
    }

    public HerbivorousFactory() {
    }
}
