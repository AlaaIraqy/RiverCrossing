
import java.awt.image.BufferedImage;

/**
 *
 * @author EGYPT_LAPTOP
 */
public class Man extends People{
    private double weight=90;
    private String label="90";
    public double getWeight() {
        return weight;
    }

    public Man() {
    }

    public String getLabel() {
        return label;
    }

    @Override
    public BufferedImage[] getImages() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ICrosser makeCopy() {
        return new Man();
    }
    @Override
    public void setLabelToBeShown(String label) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
