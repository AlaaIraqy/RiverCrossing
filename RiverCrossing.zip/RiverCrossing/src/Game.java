import java.awt.image.BufferedImage;
import javafx.application.Application;
import javafx.embed.swing.SwingFXUtils;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
public class Game extends Application{
    

public static void main(String[] args){
    launch(args);
}
    @Override
    public void start(Stage primaryStage) throws Exception {
        Carnivorous c=new Carnivorous();
        Herbivorous h=new Herbivorous();
        System.out.println("Weight=" + c.getWeight());
        Group root=new Group();
        Scene scene=new Scene(root, 600, 600);
        Canvas canvas=new Canvas( 600, 600);
        root.getChildren().addAll(canvas);
        GraphicsContext gc= canvas.getGraphicsContext2D();
        Image imagefront = SwingFXUtils.toFXImage(c.getImages()[0], null);
        animalGUI frontanimal=new animalGUI(imagefront);
        frontanimal.setPositionX(100);
        frontanimal.setPositionX(100);
        frontanimal.render(gc);
        Image imageback = SwingFXUtils.toFXImage(c.getImages()[1], null);
        animalGUI backanimal=new animalGUI(imageback);
        backanimal.setPositionX(200);
        backanimal.setPositionX(200);
        backanimal.render(gc);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

}