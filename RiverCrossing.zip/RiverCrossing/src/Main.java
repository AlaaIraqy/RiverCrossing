/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Heba Ahmed
 */
public class Main {
    /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
    
  /*  public static void main(String[] args) {
        Carnivorous c=new Carnivorous();
        System.out.println("Weight=" + c.getWeight());
        System.out.print("Label="+c.getLabelToBeShown());
    }*/
    

}
